exports.PREFIX = "+";
exports.OWNER_ID = "";
exports.Owner_Name = "";